import java.util.InputMismatchException;
import java.util.Scanner;

interface A{
    void add();
    void issue();
    void ret();
    void details();
    void exit();
}

class Methods_Variables implements A{
    private int bookID;
    private int price;
    static int inpt2;
    static String str,date,rdate;
    static int id,total;
    static int inpt;
    public void add(){}
    public void issue(){}
    public   void ret(){}
    public void details(){}
    public void exit(){}

    public void setBook_ID(int bookID) {
        this.bookID=bookID;
    }
    public int getBook_ID(){
        return bookID;
    }
    public void setPrice(int price){
        this.price=price;
    }
    public int getPrice(){
        return price;
    }
}


class Main extends Methods_Variables{
    public static void main(String[] args) {

        do {
            System.out.println("###########-Library Management System-#########");
            System.out.println("Insert 1 to add a Book");
            System.out.println("Insert 2 to issue a book");
            System.out.println("Insert 3 to return a book");
            System.out.println("Insert 4 to print details");
            System.out.println("Insert 5 to exit the program");
            Scanner s0 = new Scanner(System.in);
            System.out.println("Enter one of the options from above");
            try
            {
                inpt = s0.nextInt();}
            catch (InputMismatchException e){ System.out.println(e);
                System.out.println("Input should be in numbers not in characters");
            }

            switch (inpt) {
                case 1:
                    Library L1 = new Library() {
                    };
                    L1.add();
                    break;
                case 2:
                    Library L2 = new Library();
                    L2.issue();
                    break;
                case 3:
                    Library L3 = new Library();
                    L3.ret();
                    break;
                case 4:
                    Library L4 = new Library();
                    L4.details();
                    break;
                case 5:
                    Library L5 = new Library();
                    L5.exit();
                default:
                    System.out.println("You Inserted an Invalid Input");
            }

            Scanner scan = new Scanner(System.in);
            System.out.println("If you want to proceed to main menu insert 0 if not then 1");
            try {inpt2 = scan.nextInt();}
            catch (InputMismatchException e){ System.out.println(e);
                System.out.println("Input should be in numbers not in characters");
            }
        }


        while (inpt2 == 0);
        if(inpt2 == 1)
        {
            Library L6 = new Library();
            L6.exit();
        }


    }
}

class Library extends Methods_Variables{

    public void add() {
        Scanner s1 = new Scanner(System.in);
        System.out.println("Enter Book Name, BOOK ID and Price");
        String str = s1.nextLine();
        try{ setPrice(s1.nextInt());
            setBook_ID(s1.nextInt());
            System.out.println("Details ");
            System.out.println("Name: "+str);
            System.out.println("Price: "+getPrice());
            System.out.println("BOOK ID: "+getBook_ID());}
        catch (InputMismatchException e){ System.out.println(e);
            System.out.println("Input should be in numbers not in characters");
        }
    }
    public void issue(){
        Scanner s2 = new Scanner(System.in);
        System.out.println("Book Title");
        str=s2.nextLine();
        System.out.println("Book ID");
        try {id=s2.nextInt();}
        catch (InputMismatchException e){ System.out.println(e);
            System.out.println("Input should be in numbers not in characters");
        }
        s2.nextLine();
        System.out.println("Issue Date");
        date=s2.nextLine();
        System.out.println("Total number of books issued");
        try{total=s2.nextInt();}
        catch (InputMismatchException e){ System.out.println(e);
            System.out.println("Input should be in numbers not in characters");
        }

        s2.nextLine();
        System.out.println("Return Date");
        rdate=s2.nextLine();
    }


    public void ret(){
        System.out.println("Enter your name and Book ID");
        Scanner s3= new Scanner(System.in);
        s3.nextLine();
        try{ setBook_ID(s3.nextInt());
            if(id==getBook_ID()){
                System.out.println("Total Details");
                System.out.println("Book name: "+ str);
                System.out.println("Book ID: "+id);
                System.out.println("Issued date: "+date);
                System.out.println("Total number of books issued: "+date);
                System.out.println("Return Date: "+rdate);
            }
            else{
                System.out.println("No match found");
            }}
        catch (InputMismatchException e){ System.out.println(e);
            System.out.println("Input should be in numbers not in characters");
        }
    }
    public void details(){
        System.out.println("Total Details");
        System.out.println("Book name: "+str);
        System.out.println("Book ID: "+id);
        System.out.println("Issued date: "+date);
        System.out.println("Total number of books issued: "+total);
        System.out.println("Return Date: "+ rdate);
    }
    public void exit(){
        System.exit(0);
    }
}




